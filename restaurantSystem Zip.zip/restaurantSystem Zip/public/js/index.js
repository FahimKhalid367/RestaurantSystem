function promptAdminPass(event) {
    event.preventDefault(); // Prevent the default form submission

    const passkey = prompt("Enter Admin Passkey:");
    if (!passkey) {
        alert("Passkey is required/invalid.");
        return;

    }

    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '../controllers/admin-auth.php';

    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'passkey';
    input.value = passkey;

    form.appendChild(input);
    document.body.appendChild(form);
    form.submit();
}



