<?php
session_start();
require_once '../models/db.php';

// Ensure only admins can access
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// 1️⃣ Get total orders
$totalOrders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();

// 2️⃣ Get total sales
$totalSales = $pdo->query("SELECT SUM(total) FROM orders")->fetchColumn();
$totalSales = $totalSales ? number_format($totalSales, 2) : '0.00';

// 3️⃣ Orders by status
$orderStatusStmt = $pdo->query("
    SELECT status, COUNT(*) AS count
    FROM orders
    GROUP BY status
");
$orderStatus = $orderStatusStmt->fetchAll(PDO::FETCH_ASSOC);

// 4️⃣ Most popular dishes (top 5)
$popularItemsStmt = $pdo->query("
    SELECT mi.name, SUM(oi.quantity) AS total_qty
    FROM order_items oi
    JOIN menu_items mi ON oi.menu_item_id = mi.id
    GROUP BY oi.menu_item_id
    ORDER BY total_qty DESC
    LIMIT 5
");
$popularItems = $popularItemsStmt->fetchAll(PDO::FETCH_ASSOC);

// 5️⃣ Latest reservations (latest 5)
$reservationsStmt = $pdo->query("
    SELECT customer_name, reservation_date, reservation_time, party_size
    FROM reservations
    ORDER BY reservation_date DESC, reservation_time DESC
    LIMIT 5
");
$recentReservations = $reservationsStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body style="background-color: tomato;">
    <nav class="navbar navbar-expand-lg ">
        <div class="container-fluid">
            <div class="collapse navbar-collapse justify-content-end">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace;" href="manage-menu.php">Manage Menu |</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace;" href="staff-order-management.php">Order Management |</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace;" href="../controllers/logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <h2 class="mb-4 text-center" style="color: white;">📊 Dashboard Overview</h2>

        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card text-bg-primary text-center">
                    <div class="card-body">
                        <h5 class="card-title">Total Orders</h5>
                        <p class="display-5"><?= $totalOrders ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-bg-success text-center">
                    <div class="card-body">
                        <h5 class="card-title">Total Sales</h5>
                        <p class="display-5">£<?= $totalSales ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-bg-info text-center">
                    <div class="card-body">
                        <h5 class="card-title">Orders by Status</h5>
                        <?php foreach ($orderStatus as $status): ?>
                            <p class="mb-1"><?= htmlspecialchars($status['status']) ?>: <?= $status['count'] ?></p>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header bg-secondary text-white">
                        🥇 Top 5 Popular Dishes
                    </div>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($popularItems as $item): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?= htmlspecialchars($item['name']) ?>
                                <span class="badge bg-primary rounded-pill"><?= $item['total_qty'] ?> ordered</span>
                            </li>
                        <?php endforeach; ?>
                        <?php if (empty($popularItems)): ?>
                            <li class="list-group-item text-muted">No orders yet.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header bg-secondary text-white">
                        🗓️ Latest Reservations
                    </div>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($recentReservations as $res): ?>
                            <li class="list-group-item">
                                <strong><?= htmlspecialchars($res['customer_name']) ?></strong> - <?= $res['party_size'] ?> people <br>
                                <?= htmlspecialchars($res['reservation_date']) ?> at <?= htmlspecialchars($res['reservation_time']) ?>
                            </li>
                        <?php endforeach; ?>
                        <?php if (empty($recentReservations)): ?>
                            <li class="list-group-item text-muted">No reservations yet.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-white text-center py-3">
        What A Burger © 2025
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
