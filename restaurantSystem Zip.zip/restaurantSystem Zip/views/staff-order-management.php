<?php
session_start();
require_once '../models/db.php';

// ✅ Ensure only staff/admin access
if ($_SESSION['user_role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// 🔄 Fetch orders
$stmtOrders = $pdo->query("SELECT * FROM orders ORDER BY order_date DESC");
$orders = $stmtOrders->fetchAll(PDO::FETCH_ASSOC);

// 🔄 Fetch reservations
$stmtReservations = $pdo->query("SELECT * FROM reservations ORDER BY reservation_date DESC");
$reservations = $stmtReservations->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Order Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body style="background-color: tomato;">

<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace;" href="index.php">Home |</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace;" href="menu.php">Menu |</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace;" href="manage-menu.php">Manage Menu |</a>
                    <li class="nav-item">
                        <a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace;" href="admin-dashboard.php">Admin Dashboard</a>
                    </li>
                </li>
            </ul>
        </div>
    </div>
</nav>


    <div class="container my-5">
        <h2 class="mb-4 text-center" style="color: white;">📦 Online Orders</h2>

        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Order ID</th>
                    <th>User Email</th>
                    <th>Order Date</th>
                    <th>Status</th>
                    <th>Total</th>
                    <th>Special Request</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= $order['id'] ?></td>
                        <td><?= htmlspecialchars($order['user_email']) ?></td>
                        <td><?= $order['order_date'] ?></td>
                        <td><?= $order['status'] ?></td>
                        <td>£<?= number_format($order['total'], 2) ?></td>
                        <td>
                            <?php if (!empty($order['note'])): ?>
                                <?= nl2br(htmlspecialchars($order['note'])) ?>
                            <?php else: ?>
                                <em>No note</em>
                            <?php endif; ?>
                        </td>
                        <td>
                            <!-- ✅ Status update form -->
                            <form action="../controllers/update-order-status.php" method="POST" class="d-flex gap-2">
                                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                <select name="status" class="form-select form-select-sm">
                                    <option value="Preparing" <?= $order['status'] === 'Preparing' ? 'selected' : '' ?>>Preparing</option>
                                    <option value="Ready for Pickup" <?= $order['status'] === 'Ready for Pickup' ? 'selected' : '' ?>>Ready for Pickup</option>
                                    <option value="Delivered" <?= $order['status'] === 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                                    <option value="Cancelled" <?= $order['status'] === 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                </select>
                                <button type="submit" class="btn btn-sm btn-primary">Update</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Reservations Section -->
        <h2 class="mt-5 mb-4 text-center" style="color: white;">🍽️ Eat-In Reservations</h2>

        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Reservation ID</th>
                    <th>User Email</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Party Size</th>
                    <th>Note</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reservations as $res): ?>
                    <tr>
                        <td><?= $res['id'] ?></td>
                        <td><?= htmlspecialchars($res['user_email']) ?></td>
                        <td><?= $res['reservation_date'] ?></td>
                        <td><?= $res['reservation_time'] ?></td>
                        <td><?= (int)$res['party_size'] ?></td>
                        <td>
                            <?php if (!empty($res['note'])): ?>
                                <?= nl2br(htmlspecialchars($res['note'])) ?>
                            <?php else: ?>
                                <em>No note</em>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Logout button -->
        <div class="text-center mt-4">
            <a href="../controllers/logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

