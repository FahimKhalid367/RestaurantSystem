<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Redirecting to Stripe...</title>
</head>
<body>
  <form id="stripeForm" action="../controllers/create-checkout-session.php" method="POST">
    <button type="submit" style="display:none;">Pay Now</button>
  </form>
  <script>document.getElementById('stripeForm').submit();</script>
</body>
</html>
