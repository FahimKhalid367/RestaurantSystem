<?php
session_start();
require_once '../models/db.php';

$userId = $_SESSION['user_email'] ?? null;

if (!$userId) {
    header('Location: login.php');
    exit();
}

// Fetch reservations for the logged-in user
$stmt = $pdo->prepare("SELECT * FROM reservations WHERE user_email = ? ORDER BY reservation_date, reservation_time");
$stmt->execute([$userId]);
$reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Reservations</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body style="background-color: tomato;">
<nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarLinks" aria-controls="navbarLinks" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarLinks">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link text-white fs-5" style="font-family: 'Courier New', Courier, monospace" href="menu.php">Menu |</a></li>
                    <li class="nav-item"><a class="nav-link text-white fs-5" style="font-family: 'Courier New', Courier, monospace" href="cart.php">Cart </a></li>

                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <h2 class="mb-4 text-center" style="color: white;">📅 My Reservations</h2>

        <?php if (empty($reservations)): ?>
            <p class="text-center">You have no reservations yet.</p>
            <div class="text-center">
                <a href="menu.php" class="btn btn-primary mt-3">Back to Menu</a>
            </div>
        <?php else: ?>
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Party Size</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Note</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reservations as $res): ?>
                        <tr>
                            <td><?= htmlspecialchars($res['reservation_date']) ?></td>
                            <td><?= htmlspecialchars($res['reservation_time']) ?></td>
                            <td><?= (int)$res['party_size'] ?></td>
                            <td><?= htmlspecialchars($res['customer_name']) ?></td>
                            <td><?= htmlspecialchars($res['phone_number']) ?></td>
                            <td>
                                <?php if (!empty($res['note'])): ?>
                                    <?= nl2br(htmlspecialchars($res['note'])) ?>
                                <?php else: ?>
                                    <em>No note</em>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <!-- Edit button -->
                                <button type="button" class="btn btn-sm btn-warning mb-2" data-bs-toggle="modal" data-bs-target="#editModal<?= $res['id'] ?>">
                                    Edit
                                </button>

                                <!-- Cancel form -->
                                <form action="../controllers/cancel-reservation.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="reservation_id" value="<?= $res['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to cancel this reservation?');">Cancel</button>
                                </form>
                            </td>
                        </tr>

                        <!-- Edit Reservation Modal -->
                        <div class="modal fade" id="editModal<?= $res['id'] ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $res['id'] ?>" aria-hidden="true">
                            <div class="modal-dialog">
                                <form method="POST" action="../controllers/update-reservation.php">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="editModalLabel<?= $res['id'] ?>">Edit Reservation</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <input type="hidden" name="reservation_id" value="<?= $res['id'] ?>">

                                            <div class="mb-3">
                                                <label class="form-label">Name</label>
                                                <input type="text" name="customer_name" class="form-control" value="<?= htmlspecialchars($res['customer_name']) ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Phone Number</label>
                                                <input type="tel" name="phone_number" class="form-control" value="<?= htmlspecialchars($res['phone_number']) ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Date</label>
                                                <input type="date" name="reservation_date" class="form-control" value="<?= htmlspecialchars($res['reservation_date']) ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Time</label>
                                                <input type="time" name="reservation_time" class="form-control" value="<?= htmlspecialchars($res['reservation_time']) ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Party Size</label>
                                                <input type="number" name="party_size" class="form-control" value="<?= (int)$res['party_size'] ?>" min="1" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Special Request (Optional)</label>
                                                <textarea name="note" class="form-control" rows="3" maxlength="250"><?= htmlspecialchars($res['note']) ?></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

