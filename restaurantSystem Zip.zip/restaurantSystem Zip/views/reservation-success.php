<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reservation Confirmed</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<body style="background-color: tomato">
  <div class="container text-center my-5">
    <h1 class="text-success">✅ Table Reserved!</h1>
    <p class="lead" style="color: white;">A confirmation email has been sent with your reservation details.</p>
    <a href="menu.php" class="btn btn-primary mt-3">Back to Menu</a>
  </div>
</body>
</html>
