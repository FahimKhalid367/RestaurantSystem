<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reservation Failed</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
  <div class="container text-center my-5">
    <h1 class="text-danger">⚠️ Reservation Not Allowed</h1>
    <p class="lead">You already have a reservation at the same date and time. Please choose a different time.</p>
    <a href="cart.php" class="btn btn-primary mt-3">Back to Cart</a>
  </div>
</body>
</html>
