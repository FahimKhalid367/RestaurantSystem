<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Your Custom CSS -->
    <link rel="stylesheet" href="..\public\css\styles.css">
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarLinks" aria-controls="navbarLinks" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarLinks">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link text-white fs-5" style="font-family: 'Courier New', Courier, monospace" href="login.php">Login |</a></li>
                    <li class="nav-item"><a class="nav-link text-white fs-5" style="font-family: 'Courier New', Courier, monospace" href="sign-up.php">Register |</a></li>
                    <li class="nav-item"><a class="nav-link text-white fs-5" style="font-family: 'Courier New', Courier, monospace" href="menu.php">Menu |</a></li>
                    <li class="nav-item"><a class="nav-link text-white fs-5" style="font-family: 'Courier New', Courier, monospace" href="cart.php">Cart |</a></li>
                    <a class="nav-link text-white fs-5" href="#" style="font-family: 'Courier New', Courier, monospace" onclick="promptAdminPass(event)">Admin</a>

                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="container text-center my-5">
        <h1 class="index-title">Welcome to What A Burger</h1>
        <div class="index-container">
            <img src="..\public\images\burger-title.png" alt="burger-picture" class="img-fluid index-image">
            <p class="index-description mt-3">The best burger place in town!</p>
        </div>
    </div>

    <!-- Ordering Platforms -->
    <div class="container text-center my-5">
        <h2 class="available-at-title">You can order from our website or at:</h2>
        <div class="d-flex justify-content-center gap-4 flex-wrap mt-3">
            <img class="logo img-fluid" src="..\public\images\Just-Eat-Logo.png" alt="just-eat">
            <img class="logo img-fluid" src="..\public\images\Deliveroo-Logo.png" alt="deliveroo">
            <img class="logo img-fluid" src="..\public\images\uber-eats-logo.png" alt="uber-eats">
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-white text-center py-3">
        What A Burger 2025 ©
    </footer>

    <!-- Bootstrap JS (for navbar toggler) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="..\public\js\index.js"></script>
</body>
</html>
