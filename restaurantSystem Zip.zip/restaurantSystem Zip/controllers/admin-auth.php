<?php
session_start();

$correctPasskey = 'Admin123';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputKey = $_POST['passkey'] ?? '';

    if ($inputKey === $correctPasskey) {
        $_SESSION['admin_verified'] = true;
        // Only redirect to staff-sign-up if passkey matches
        header('Location: ../views/staff-sign-up.php');
        exit();
    } else {
        // Invalid passkey: show alert and stop here
        echo "<script>
                alert('Incorrect or missing admin passkey.');
                window.location.href = '../views/index.php';
              </script>";
        exit();
    }
}

// Block direct GET access
header('Location: ../views/index.php');
exit();



