<?php
session_start();
require_once '../models/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Grab POST data safely
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $repeatPassword = $_POST['repeat-password'] ?? '';
    $role = $_POST['role'] ?? 'customer';  // default to 'customer' if not set

    // Validate name
    if (strlen($name) < 2 || !preg_match('/^[a-zA-Z\s]+$/', $name)) {
        exit('❌ Invalid name. Must be at least 2 characters and letters only.');
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        exit('❌ Invalid email format.');
    }

    // Validate password strength
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password)) {
        exit('❌ Password must be at least 8 characters and include uppercase, lowercase, and a number.');
    }

    // Check passwords match
    if ($password !== $repeatPassword) {
        exit('❌ Passwords do not match.');
    }

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        exit('❌ This email is already registered. Please log in instead.');
    }

    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert user into DB
    $insert = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
    $insert->execute([$name, $email, $hashedPassword, $role]);

    // Success - redirect to login or admin dashboard based on role
    if ($role === 'admin') {
        echo "<script>
            alert('✅ Admin registered successfully! Please log in.');
            window.location.href = '../views/login.php';
        </script>";
    } else {
        echo "<script>
            alert('✅ Registration successful! Please log in.');
            window.location.href = '../views/login.php';
        </script>";
    }
    exit();
} else {
    // Not a POST request
    header('Location: ../views/sign-up.php');
    exit();
}
