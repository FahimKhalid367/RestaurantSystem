<?php
session_start();
require_once '../models/db.php';

// ✅ At the top, load PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId      = $_SESSION['user_id'] ?? null;
    $userEmail   = $_SESSION['user_email'] ?? null;
    $customerName = $_POST['customer_name'];
    $phoneNumber  = $_POST['phone_number'];
    $date         = $_POST['reservation_date'];
    $time         = $_POST['reservation_time'];
    $partySize    = (int) $_POST['party_size'];
    $note = trim($_POST['note'] ?? '');
    $cart         = $_SESSION['cart'] ?? [];
    $total        = 0;

    // ✅ Guard: Block if user is not logged in
    if (!$userId || !$userEmail) {
        echo "<script>alert('You must be logged in to make a reservation.'); window.location.href = '../views/login.php';</script>";
        exit();
    }

    // 1️⃣ Insert the order if the cart is not empty
    $orderId = null;
    if (!empty($cart)) {
        foreach ($cart as $item) {
            $total += $item['price'] * $item['quantity'];
        }

        // Insert into orders table (both user_id + user_email for clarity)
        $stmtOrder = $pdo->prepare("INSERT INTO orders (user_id, user_email, total) VALUES (?, ?, ?)");
        $stmtOrder->execute([$userId, $userEmail, $total]);
        $orderId = $pdo->lastInsertId();

        // Insert each item into order_items table
        $stmtItem = $pdo->prepare("
        INSERT INTO order_items (order_id, menu_item_id, item_name, price, quantity)
        VALUES (?, ?, ?, ?, ?)
    ");
    foreach ($cart as $menuItemId => $item) {
        $stmtItem->execute([
            $orderId,
            $menuItemId,
            $item['name'],      // 🆕 item_name
            $item['price'],
            $item['quantity']
        ]);
}


    }

    // 2️⃣ Insert the reservation with linked order_id
    $stmtRes = $pdo->prepare("
        INSERT INTO reservations 
        (user_email, reservation_date, reservation_time, party_size, customer_name, phone_number, order_id, note) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmtRes->execute([$userEmail, $date, $time, $partySize, $customerName, $phoneNumber, $orderId, $note]);

    // 3️⃣ Send confirmation email
    require_once __DIR__ . '/../vendor/autoload.php';

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.mailersend.net';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'MS_FF5Ah4@test-zxk54v88p36ljy6v.mlsender.net';
        $mail->Password   = 'mssp.KPAA1ej.3z0vklozy8p47qrx.iGISxVd';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->setFrom('MS_FF5Ah4@test-zxk54v88p36ljy6v.mlsender.net', 'What A Burger');
        $mail->addAddress($userEmail);

        $mail->isHTML(true);
        $mail->Subject = 'Your Table Reservation Confirmation';

        // Build email body
        $body = "
            <h3>🍔 Your Table is Reserved!</h3>
            <p><strong>Name:</strong> {$customerName}</p>
            <p><strong>Phone:</strong> {$phoneNumber}</p>
            <p><strong>Date:</strong> {$date}</p>
            <p><strong>Time:</strong> {$time}</p>
            <p><strong>Number of People:</strong> {$partySize}</p>
        ";

        // If there's a food order, include it in the email
        if (!empty($cart)) {
            $body .= "<h4>Ordered Items:</h4><ul>";
            foreach ($cart as $item) {
                $body .= "<li>{$item['quantity']}x {$item['name']} (£" . number_format($item['price'], 2) . " each)</li>";
            }
            $body .= "</ul>";
            $body .= "<p><strong>Total:</strong> £" . number_format($total, 2) . "</p>";
        }

        $body .= "<p>We look forward to seeing you at What A Burger!</p>";

        $mail->Body = $body;
        $mail->send();
    } catch (Exception $e) {
        error_log("MailerSend error: {$mail->ErrorInfo}");
    }

    // ✅ Optionally clear cart after reservation:
    // unset($_SESSION['cart']);

    // Redirect to success page
    header('Location: ../views/reservation-success.php');
    exit();

    
}


// SMS confirmation
// Set up SMS details
$apiKey = 'mlsn.926484d72e4c307cb833922345aede6d92cdbfc1cc02fa0607c755f378b6d20e';
$url = 'https://api.mailersend.com/v1/sms-send';

$data = [
    'from' => 'What A Burger',  // Sender ID 
    'to'   => $phoneNumber,    // The user's phone number 
    'text' => "Hi $customerName, your What A Burger reservation for $reservationDate at $reservationTime is confirmed. We look forward to seeing you!"
];

// Initialize cURL
$ch = curl_init($url);

// Set cURL options
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

// Execute the request
$response = curl_exec($ch);

// Error handling
if (curl_errno($ch)) {
    error_log('SMS error: ' . curl_error($ch));
} else {
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if ($httpCode >= 400) {
        error_log('SMS failed: ' . $response);
    }
}

// Close cURL
curl_close($ch);
