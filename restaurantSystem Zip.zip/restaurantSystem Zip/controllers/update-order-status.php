<?php
require_once '../models/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderId = (int)$_POST['order_id'];
    $status  = $_POST['status'];

    if ($orderId && $status) {
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$status, $orderId]);
    }
}

header('Location: ../views/staff-order-management.php');
exit();


