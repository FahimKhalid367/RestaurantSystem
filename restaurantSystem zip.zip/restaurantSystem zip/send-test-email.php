<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.mailersend.net';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'MS_FF5Ah4@test-zxk54v88p36ljy6v.mlsender.net';
    $mail->Password   = 'mssp.KPAA1ej.3z0vklozy8p47qrx.iGISxVd';
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom('MS_FF5Ah4@test-zxk54v88p36ljy6v.mlsender.net', 'What A Burger');
    $mail->addAddress('fahim367@hotmail.co.uk');

    $mail->isHTML(true);
    $mail->Subject = 'Test Email';
    $mail->Body    = '<h2>This is a test email from What A Burger</h2>';

    $mail->send();
    echo 'Test email sent successfully.';
} catch (Exception $e) {
    echo "MailerSend error: {$mail->ErrorInfo}";
}
