<?php
require_once __DIR__ . '/../vendor/autoload.php';


echo 'autoload path: ' . __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../vendor/autoload.php';
echo ' – autoload loaded!<br>';


\Stripe\Stripe::setApiKey('sk_test_51RLqTMFNlH3j84LP8P9mlPweuITqvVc2BOSy2MDXNI7mnpISwwLAox0HyFSR9pGEGXO0dzLSJiL2iPXyHOkRX3NX00rvYHX0ei');
