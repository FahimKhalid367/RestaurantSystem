<?php
session_start();
$cart = $_SESSION['cart'] ?? [];
$total = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../public/css/styles.css">
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace" href="index.php">Home |</a></li>
                <li class="nav-item"><a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace" href="menu.php">Menu |</a></li>
                <li class="nav-item"><a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace" href="../controllers/logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<h1 class="index-title" style="font-weight: bold;">What A Burger</h1>
<br>
<h1 class="index-title">Tasty Food</h1>
<h2 style="color: white; font-family: 'Courier New', Courier, monospace; text-align: center;">One Click Away!</h2>

<div class="container my-5">
    <h2 class="mb-4" style="color: white; font-family: 'Courier New', Courier, monospace;">Your Cart</h2>

    <?php if (empty($cart)): ?>
        <p style="color: white;">Your cart is empty.</p>
    <?php else: ?>
        <form method="POST" action="../controllers/update-cart.php">
            <table class="table table-light table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Item</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Subtotal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart as $id => $item):
                        $subtotal = $item['price'] * $item['quantity'];
                        $total += $subtotal;
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($item['name']) ?></td>
                            <td>£<?= number_format($item['price'], 2) ?></td>
                            <td>
                                <input type="number" name="quantities[<?= $id ?>]" value="<?= $item['quantity'] ?>" min="1" class="form-control" style="width: 80px;">
                            </td>
                            <td>£<?= number_format($subtotal, 2) ?></td>
                            <td>
                                <button type="submit" name="remove" value="<?= $id ?>" class="btn btn-danger btn-sm">Remove</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="3" class="text-end">Total:</th>
                        <th colspan="2">£<?= number_format($total, 2) ?></th>
                    </tr>
                </tfoot>
            </table>

            <div class="d-flex justify-content-between">
                <a href="menu.php" class="btn btn-secondary">Back to Menu</a>
                <button type="submit" name="update" class="btn btn-success">Update Cart</button>
            </div>
        </form>

        <!-- NEW: Add Note and Checkout Form -->
        <form method="POST" action="checkout.php" class="mt-4">
            <div class="mb-3">
                <label for="orderNote" class="form-label text-white">Add a note to your order (optional):</label>
                <textarea name="order_note" id="orderNote" class="form-control" rows="3" placeholder="E.g., No onions, extra ketchup..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Proceed to Payment</button>
            <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#reservationModal">
                Eat In-Store (Reserve a Table)
            </button>

        </form>
    <?php endif; ?>
</div>

<!-- Reservation Modal -->
<div class="modal fade" id="reservationModal" tabindex="-1" aria-labelledby="reservationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="../controllers/create-reservation.php">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="reservationModalLabel">Reserve a Table</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="resDate" class="form-label">Date</label>
                        <input type="date" name="reservation_date" id="resDate" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="resTime" class="form-label">Time</label>
                        <input type="time" name="reservation_time" id="resTime" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="partySize" class="form-label">Number of People</label>
                        <input type="number" name="party_size" id="partySize" class="form-control" min="1" required>
                    </div>
                    <div class="mb-3">
                        <label for="custName" class="form-label">Name</label>
                        <input type="text" name="customer_name" id="custName" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="phoneNumber" class="form-label">Phone Number</label>
                        <input type="tel" name="phone_number" id="phoneNumber" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="note" class="form-label">Special Request (Optional)</label>
                        <textarea name="note" id="note" class="form-control" rows="3" maxlength="250" placeholder="E.g., Table by the window, allergy info..."></textarea>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Reserve</button>
                </div>
            </div>
        </form>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

