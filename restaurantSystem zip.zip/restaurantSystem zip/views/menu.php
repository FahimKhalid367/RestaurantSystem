<?php
require_once '../models/db.php'; // Connect to DB
session_start();

// Fetch all available menu items
$stmt = $pdo->query("SELECT * FROM menu_items WHERE is_available = 1");
$menuItems = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Browse Menu</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../public/css/styles.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <div class="collapse navbar-collapse justify-content-end">
        <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace" href="index.php">Home |</a></li>
          <li class="nav-item"><a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace" href="cart.php">Cart |</a></li>
          <li class="nav-item"><a class="nav-link text-white" style="color: white; font-family: 'Courier New', Courier, monospace" href="my-reservations.php">My Reservations |</a></li>
          <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
          <li class="nav-item">
              <a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace" href="manage-menu.php">Manage Menu |</a>
          </li>
          <?php endif; ?>

          <li class="nav-item"><a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace" href="../controllers/logout.php">Logout</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <h1 class="index-title">Welcome to What A Burger</h1>

  <div class="container my-5">
    <h2 class="text-center mb-4" style="color: white; font-family: 'Courier New', Courier, monospace;">Our Menu</h2>
    <div class="row" style="text-align: center;">
      <?php foreach ($menuItems as $item): ?>
        <div class="col-md-4 mb-4">
          <div class="card h-100">
          <img src="../public/images/<?= htmlspecialchars($item['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($item['name']) ?>">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title"><?= htmlspecialchars($item['name']) ?></h5>
              <p class="card-text"><?= htmlspecialchars($item['description']) ?></p>
              <div class="mt-auto">
                <p class="card-text fw-bold">£<?= number_format($item['price'], 2) ?></p>
                <form method="POST" action="../controllers/add-to-cart.php" class="d-grid gap-2">
                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
    
                        <label for="qty<?= $item['id'] ?>" class="form-label mt-2">Quantity:</label>
                        <select name="quantity" id="qty<?= $item['id'] ?>" class="form-select mb-2">
                <?php for ($i = 1; $i <= 10; $i++): ?>
            <option value="<?= $i ?>"><?= $i ?></option>
        <?php endfor; ?>
    </select>

    <button type="submit" class="btn btn-primary">Add to Cart</button>
</form>

              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <footer class="text-white text-center py-3">What A Burger 2025 ©</footer>
</body>
</html>

