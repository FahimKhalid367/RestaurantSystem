<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <!-- BootStrap StyleSheet -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="..\public\css\styles.css">
</head>
<body>
    <div class="logo">
        <h2 class="page-title">What A Burger</h2>

    </div>
<!-- Sign Up Form -->
    <div class="container-fluid vh-100 d-flex justify-content-center align-items-center">
        <div class="row justify-content-center w-75">
            <div class="col-md-8 col-lg-6">
                <div class="sign-up-container p-4 text-center bg-light border rounded">
                    <h3 class="sign-up-title" style="text-align: center;">Sign Up (Admin)</h3>
                    <form id="signupFormAdmin" action="../controllers/registerController.php" method="POST">
                        <input type="hidden" name="role" value="admin">
                        <input type="text" name="name" class="form-control mb-3" placeholder="Full Name" required>
                        <input type="email" name="email" class="form-control mb-3" placeholder="Email" required>
                        <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
                        <input type="password" name="repeat-password" class="form-control mb-3" placeholder="Repeat Password" required>
                        <button type="submit" class="btn btn-primary btn-block">Sign Up</button>
                        <p class="mt-3">Already have an account? <a href="login.php">Sign In</a></p>
                        <p class="mt-3">Get back to <a href="index.php">Home Page</a></p>
                    </form>

                </div>
            </div>
        </div>
    </div>
    



  <!-- Footer -->
  <footer class="text-white text-center py-3">
        What A Burger 2025 ©
    </footer>
    <script src="../public/js/signup.js"></script>
</body>
</html>