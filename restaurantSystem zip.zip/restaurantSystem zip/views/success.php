<?php
session_start();
require_once '../models/db.php';

$cart = $_SESSION['cart'] ?? [];
$userEmail = $_SESSION['user_email'] ?? 'anonymous@example.com';
$orderNote = $_SESSION['order_note'] ?? '';


$total = 0;
foreach ($cart as $item) {
    $total += $item['price'] * $item['quantity'];
}

// 1. Insert order
$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    die("Error: User is not logged in properly.");
}
$stmt = $pdo->prepare("INSERT INTO orders (user_id, user_email, total, note) VALUES (?, ?, ?, ?)");
$stmt->execute([$userId, $userEmail, $total, $orderNote]);
$orderId = $pdo->lastInsertId();

// 2. Insert items
// 2. Insert items - now using menu_item_id instead of item_name
$stmtItem = $pdo->prepare("INSERT INTO order_items (order_id, menu_item_id, quantity, price) VALUES (?, ?, ?, ?)");
foreach ($cart as $id => $item) {
    $stmtItem->execute([$orderId, $id, $item['quantity'], $item['price']]);
}


// 3. Send confirmation email before clearing cart
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.mailersend.net';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'MS_FF5Ah4@test-zxk54v88p36ljy6v.mlsender.net'; // Your MailerSend sender
    $mail->Password   = 'mssp.KPAA1ej.3z0vklozy8p47qrx.iGISxVd';        // Your MailerSend API key
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom('MS_FF5Ah4@test-zxk54v88p36ljy6v.mlsender.net', 'What A Burger');
    $mail->addAddress($userEmail);

    $mail->isHTML(true);
    $mail->Subject = 'Your What A Burger Order Confirmation';

    // Styled HTML receipt
    $body = '
    <h2 style="font-family: Arial, sans-serif; color: #2c3e50;">🍔 What A Burger - Order Confirmation</h2>
    <p>Thank you for your order! Here is your receipt:</p>
    <table cellpadding="10" cellspacing="0" border="1" style="border-collapse: collapse; width: 100%; font-family: Arial, sans-serif;">
        <thead style="background-color: #f8f9fa;">
            <tr>
                <th align="left">Item</th>
                <th align="center">Qty</th>
                <th align="right">Price</th>
                <th align="right">Subtotal</th>
            </tr>
        </thead>
        <tbody>';

    foreach ($cart as $item) {
        $subtotal = $item['quantity'] * $item['price'];
        $body .= '
            <tr>
                <td>' . htmlspecialchars($item['name']) . '</td>
                <td align="center">' . $item['quantity'] . '</td>
                <td align="right">£' . number_format($item['price'], 2) . '</td>
                <td align="right">£' . number_format($subtotal, 2) . '</td>
            </tr>';
    }

    $body .= '
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" align="right"><strong>Total:</strong></td>
                <td align="right"><strong>£' . number_format($total, 2) . '</strong></td>
            </tr>
        </tfoot>
    </table>
    <p style="margin-top: 20px;">We hope you enjoy your meal!</p>
    <p>– What A Burger Team</p>';

    $mail->Body = $body;
    $mail->send();
} catch (Exception $e) {
    error_log("MailerSend error: {$mail->ErrorInfo}");
}

// 4. Clear the cart after sending
unset($_SESSION['cart']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Successful</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container text-center my-5">
        <h1 class="text-success">✅ Payment Successful!</h1>
        <p class="lead">Your order has been placed. A confirmation email has been sent to <strong><?= htmlspecialchars($userEmail) ?></strong>.</p>
        <a href="menu.php" class="btn btn-primary mt-3">Back to Menu</a>
    </div>
</body>
</html>



