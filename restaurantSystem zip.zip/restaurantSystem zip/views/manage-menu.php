<?php
session_start();
require_once '../models/db.php';

// Ensure only admins can access
if ($_SESSION['user_role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Fetch all menu items
$stmt = $pdo->query("SELECT * FROM menu_items ORDER BY id DESC");
$menuItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Menu</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body style="background-color: tomato;">
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace;" href="staff-order-management.php">Order Management |</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color: white; font-family: 'Courier New', Courier, monospace;" href="menu.php">Menu</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
    <div class="container my-5">
        <h2 class="mb-4 text-center" style="color: white;">🍔 Admin Menu Management</h2>

        <!-- Add New Menu Item -->
        <div class="card mb-5">
            <div class="card-header">Add New Menu Item</div>
            <div class="card-body">
                <form action="../controllers/menuController.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">Item Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Price (£)</label>
                        <input type="number" step="0.01" name="price" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Image (optional)</label>
                        <input type="file" name="image" class="form-control">
                    </div>
                    <button type="submit" name="action" value="add" class="btn btn-primary">Add Item</button>
                </form>
            </div>
        </div>

        <!-- List of Menu Items -->
        <h4>Current Menu Items</h4>
        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price (£)</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($menuItems as $item): ?>
                    <tr>
                        <td>
                            <?php if (!empty($item['image'])): ?>
                                <img src="../public/images/<?= htmlspecialchars($item['image']) ?>" alt="Image" width="80">
                            <?php else: ?>
                                <em>No Image</em>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($item['name']) ?></td>
                        <td><?= nl2br(htmlspecialchars($item['description'])) ?></td>
                        <td>£<?= number_format($item['price'], 2) ?></td>
                        <td>
                            <!-- Edit Form (in modal or inline) -->
                            <button type="button" class="btn btn-sm btn-warning mb-1" data-bs-toggle="modal" data-bs-target="#editModal<?= $item['id'] ?>">
                                Edit
                            </button>
                            <form action="../controllers/menuController.php" method="POST" style="display:inline;">
                                <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                <button type="submit" name="action" value="delete" class="btn btn-sm btn-danger" onclick="return confirm('Delete this item?');">Delete</button>
                            </form>
                        </td>
                    </tr>

                    <!-- Edit Modal -->
                    <div class="modal fade" id="editModal<?= $item['id'] ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $item['id'] ?>" aria-hidden="true">
                      <div class="modal-dialog">
                        <form method="POST" action="../controllers/menuController.php" enctype="multipart/form-data">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editModalLabel<?= $item['id'] ?>">Edit Menu Item</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                    <div class="mb-3">
                                        <label class="form-label">Item Name</label>
                                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($item['name']) ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Description</label>
                                        <textarea name="description" class="form-control" required><?= htmlspecialchars($item['description']) ?></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Price (£)</label>
                                        <input type="number" step="0.01" name="price" class="form-control" value="<?= $item['price'] ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Replace Image (optional)</label>
                                        <input type="file" name="image" class="form-control">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" name="action" value="edit" class="btn btn-primary">Save Changes</button>
                                </div>
                            </div>
                        </form>
                      </div>
                    </div>

                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Logout button -->
        <div class="text-center mt-4">
            <a href="../controllers/logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
