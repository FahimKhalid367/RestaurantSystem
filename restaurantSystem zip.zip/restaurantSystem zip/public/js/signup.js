document.getElementById('signupForm').addEventListener('submit', function (e) {
    const name = this.name.value.trim();
    const email = this.email.value.trim();
    const password = this.password.value;
    const repeatPassword = this['repeat-password'].value;

    // Name validation
    if (name.length < 2 || !/^[a-zA-Z\s]+$/.test(name)) {
        alert('Please enter a valid full name (letters only, at least 2 characters).');
        e.preventDefault();
        return;
    }

    // Email format validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        e.preventDefault();
        return;
    }

    // Password validation
    const pwPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!pwPattern.test(password)) {
        alert('Password must be at least 8 characters and include uppercase, lowercase, and a number.');
        e.preventDefault();
        return;
    }

    // Password match
    if (password !== repeatPassword) {
        alert('Passwords do not match.');
        e.preventDefault();
    }
});

// Admin signup form validation
document.getElementById('signupFormAdmin').addEventListener('submit', function (e) {
    const name = this.name.value.trim();
    const email = this.email.value.trim();
    const password = this.password.value;
    const repeatPassword = this['repeat-password'].value;

    // Name validation
    if (name.length < 2 || !/^[a-zA-Z\s]+$/.test(name)) {
        alert('Please enter a valid full name (letters only, at least 2 characters).');
        e.preventDefault();
        return;
    }

    // Email format validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        e.preventDefault();
        return;
    }

    // Password validation
    const pwPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!pwPattern.test(password)) {
        alert('Password must be at least 8 characters and include uppercase, lowercase, and a number.');
        e.preventDefault();
        return;
    }

    // Password match
    if (password !== repeatPassword) {
        alert('Passwords do not match.');
        e.preventDefault();
    }
});
