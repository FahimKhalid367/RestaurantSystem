<?php
session_start();
require_once '../models/db.php';

// ✅ Check if the user is logged in
$userEmail = $_SESSION['user_email'] ?? null;

if (!$userEmail) {
    header('Location: ../views/login.php');
    exit();
}

// ✅ Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reservationId     = (int)$_POST['reservation_id'];
    $customerName      = trim($_POST['customer_name']);
    $phoneNumber       = trim($_POST['phone_number']);
    $reservationDate   = $_POST['reservation_date'];
    $reservationTime   = $_POST['reservation_time'];
    $partySize         = (int)$_POST['party_size'];
    $note              = trim($_POST['note'] ?? '');

    // ✅ Basic validation
    if ($reservationId && $customerName && $phoneNumber && $reservationDate && $reservationTime && $partySize > 0) {
        $stmt = $pdo->prepare("
            UPDATE reservations
            SET customer_name = ?, phone_number = ?, reservation_date = ?, reservation_time = ?, party_size = ?, note = ?
            WHERE id = ? AND user_email = ?
        ");
        $stmt->execute([
            $customerName, $phoneNumber, $reservationDate,
            $reservationTime, $partySize, $note,
            $reservationId, $userEmail
        ]);
    }
}

// ✅ Redirect back to the reservations page
header('Location: ../views/my-reservations.php');
exit();


