<?php
session_start();
require_once '../models/db.php';

if ($_SESSION['user_role'] !== 'admin') {
    header('Location: ../views/login.php');
    exit();
}

// Upload helper
function uploadImage($file) {
    if ($file['error'] === UPLOAD_ERR_OK) {
        $filename = time() . '_' . basename($file['name']);  // ✅ keeps extension
        $target = __DIR__ . '/../public/images/' . $filename;
        if (move_uploaded_file($file['tmp_name'], $target)) {
            return $filename;
        }
    }
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $price = floatval($_POST['price']);
        $image = isset($_FILES['image']) ? uploadImage($_FILES['image']) : null;

        $stmt = $pdo->prepare("INSERT INTO menu_items (name, description, price, image) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $description, $price, $image]);

    } elseif ($action === 'edit') {
        $id = (int)$_POST['id'];
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $price = floatval($_POST['price']);
        $image = isset($_FILES['image']) ? uploadImage($_FILES['image']) : null;

        if ($image) {
            $stmt = $pdo->prepare("UPDATE menu_items SET name = ?, description = ?, price = ?, image = ? WHERE id = ?");
            $stmt->execute([$name, $description, $price, $image, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE menu_items SET name = ?, description = ?, price = ? WHERE id = ?");
            $stmt->execute([$name, $description, $price, $id]);
        }

    } elseif ($action === 'delete') {
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM menu_items WHERE id = ?");
        $stmt->execute([$id]);
    }
}

header('Location: ../views/manage-menu.php');
exit();
