<?php
session_start();
require_once '../models/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['item_id'], $_POST['quantity'])) {
    $itemId = (int) $_POST['item_id'];
    $qty = max(1, (int) $_POST['quantity']);

    $stmt = $pdo->prepare("SELECT id, name, price FROM menu_items WHERE id = ?");
    $stmt->execute([$itemId]);
    $item = $stmt->fetch();

    if ($item) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        if (isset($_SESSION['cart'][$itemId])) {
            $_SESSION['cart'][$itemId]['quantity'] += $qty;
        } else {
            $_SESSION['cart'][$itemId] = [
                'name' => $item['name'],
                'price' => $item['price'],
                'quantity' => $qty
            ];
        }
    }
}

header('Location: ../views/menu.php');
exit();
