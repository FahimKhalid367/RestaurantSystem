<?php
session_start();
require_once '../config/stripe-config.php';

$cart = $_SESSION['cart'] ?? [];

$line_items = [];

foreach ($cart as $item) {
    $line_items[] = [
        'price_data' => [
            'currency' => 'gbp',
            'product_data' => [
                'name' => $item['name'],
            ],
            'unit_amount' => (int)($item['price'] * 100),
        ],
        'quantity' => $item['quantity'],
    ];
}

$checkout_session = \Stripe\Checkout\Session::create([
    'payment_method_types' => ['card'],
    'line_items' => $line_items,
    'mode' => 'payment',
    'success_url' => 'http://localhost/restaurantSystem/views/success.php',
    'cancel_url' => 'http://localhost/restaurantSystem/views/cart.php',
]);

header("Location: " . $checkout_session->url);
exit();
