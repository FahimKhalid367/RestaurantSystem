<?php
session_start();
require_once '../models/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reservation_id'])) {
    $reservationId = (int) $_POST['reservation_id'];
    $userEmail = $_SESSION['user_email'] ?? null;

    if ($userEmail) {
        // Delete only if reservation belongs to the logged-in user
        $stmt = $pdo->prepare("DELETE FROM reservations WHERE id = ? AND user_email = ?");
        $stmt->execute([$reservationId, $userEmail]);
    }
}

header('Location: ../views/my-reservations.php');
exit();
