<?php
session_start();

if (isset($_POST['remove'])) {
    unset($_SESSION['cart'][$_POST['remove']]);
}

if (isset($_POST['update']) && isset($_POST['quantities'])) {
    foreach ($_POST['quantities'] as $id => $qty) {
        $id = (int) $id;
        $qty = max(1, (int) $qty);
        if (isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]['quantity'] = $qty;
        }
    }
}

header('Location: ../views/cart.php');
exit();
